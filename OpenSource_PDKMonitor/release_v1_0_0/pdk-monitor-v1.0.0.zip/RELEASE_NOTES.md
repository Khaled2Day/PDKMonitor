# Release notes — PDK Monitor v1.0.0 *(rev. 7)*

**Release date:** 27 May 2026
**Author:** Emre Kaplan
**Operator:** CORNERSTONE Open Platform
**Licence:** TAPR Open Hardware License v1.0

## Official public release

This is the first formal public release of the CORNERSTONE Open
Platform PDK Monitor. The dashboard has been through a focused
25-day beta from 1 May 2026 → 26 May 2026; every feature listed
below is included and tested.

> **Revision 7** — same v1.0.0 stamp. Locks the admin-curated
> **info bar** (Contributors list + About + footer notices +
> header links) to the main `dashboard.json` so multi-slice
> fetches never overwrite it. Adds a **🐙 Global GitHub button**
> in the header — paste PAT + identity once and every flow uses
> them (sync, fetch, publish, Prepare-for-PDK). Completes the
> **multi-select bulk Move + bulk Download** with column and
> variant checkboxes plus dedicated buttons next to ↻ Sync /
> ⤓ Import. Ships the **🩹 Force-purge** rescue toolkit for
> stuck phantom BBs and the **🏷 Status manager** permanent chip
> for legacy-status cleanup. ↻ Sync and ⤓ Import buttons are
> now always rendered on every platform (with helpful disabled
> states / 🔗 Set GitHub URL inline editor when not yet wired).
> The Contributors modal has an explicit **💾 Save** button and
> is admin-only edit, single-source. See CHANGELOG.md for the
> full list.
>
> **Revision 6** — same v1.0.0 stamp. Three workflow-level
> improvements: **sync fidelity** (pre-wipe before replay, live
> file count + dead-URL pruning, simplified per-BB button to
> just `↻ Sync (N)` of working links — files deleted on the
> remote now drop out locally instead of lingering); **moveable
> + minimizable modals** so long-running operations (sync,
> fetch, AI summarise, Prepare-for-PDK) can be tucked into a
> pill at the bottom-right while you keep browsing BBs;
> **🔀 Move BB to another Technology Platform** — new button
> on the BB Details panel footer that splices the entity and
> all its files into the destination platform's column. See
> CHANGELOG.md for the full list.
>
> **Revision 5** — same v1.0.0 stamp. Adds an end-to-end **AI
> Insight** layer with a hybrid pipeline: deterministic metric
> extraction in the browser, LLM only narrates the numbers,
> every quoted number is citation-checked. Configure once from
> the header **AI Insight** button (a colour-ring badge with
> built-in 🔌 Test connection, 👁 Reveal key, 📋 Copy, monthly
> token cap), then either click **🧠 Summarise this BB** on any
> BB's new AI tab or open **💬 Chat with the agent** — a
> multi-turn conversation with read-only access to your
> dashboard via six tools (platforms, BBs, contributors,
> per-BB metrics, search, on-demand summaries). Adds a **📥
> Download Excel report** button to the Contributors modal
> (all modes) — five-sheet workbook with per-contributor
> statistics, per-platform pivot, every BB, every file, and
> metadata. Carries over rev. 4 (admin safety, cross-check
> analysis, variants-as-category, scroll fixes). See
> CHANGELOG.md for the full list.
>
> **Revision 4** — same v1.0.0 stamp. Hardens the multi-user
> distribution model and adds a full cross-check analysis suite.
> **Three-layer admin safety gate** prevents an admin publish
> into `users/` from wiping contributor folders (hard-block in
> the commit flow, strict externalize trigger, defence-in-depth
> in the orphan-file pruner). **Cross-check vs. uploaded
> dashboard** with three SVG donut charts (per-platform,
> here/there/common, variants-as-category), multi-sheet Excel
> report, and selective per-BB zip download bundling every
> file in the canonical CORNERSTONE folder layout. **Variants
> are now a first-class category** in the UI, analysis, and
> Excel report; the header bar shows `🌿 N variants` and
> `M total`. **Admin-editable footer** (Terms / TAPR / Software
> sentences). **🧹 Clear cache** button is now in every role.
> **🎁 Prepare-for-PDK** is opened to Admin. **Scroll fixed**
> across every BB tab with an inner ~3-item scroll on folder
> bodies. **Tab-named externalize subfolders** replace the old
> `PDKMonitor_*` prefix. **Instant BB-card refresh** after
> upload via a debounced `saveModel` → `render`. **Platform
> column width tuning** so the platform name stays visible at
> any width. See CHANGELOG.md for the full list.

### What's new since rev. 6

| Area | Change |
|---|---|
| **🐙 Global GitHub button** | Header button → modal with PAT + identity + display label + 🔌 Test connection + 👁 reveal + 📋 copy + 🗑 Sign out. Live chip label `● 🐙 GitHub · alice` when signed in. Every flow auto-reads — no more per-modal sign-in re-prompting. |
| **Info bar single source** | Slice merges no longer overwrite `MODEL.contributors`, `MODEL.about` (title/subtitle/version/contact/notes/logo/links) or `MODEL.legalTexts`. Only the main `dashboard.json` is authoritative. About modal shows a banner explaining the policy. |
| **Contributors modal** | Single source — only `MODEL.contributors` (auto-detect sub-table dropped). Admin draft + 💾 Save button (`💾 Save (N contributors)` when dirty; greyed `💾 Saved` when clean). Cancel changes + Close-with-unsaved confirmation gate. User-admin / read-only see a clean read-only table. |
| **Column multi-select** | Checkbox on every BB card. Ticking reveals 🔀 Move N selected (purple) + 📦 Download N selected (green) in the group head next to Sync / Import. Both buttons update labels live. |
| **Variants multi-select** | Checkboxes on every variant row + Select all + Clear + 🔀 Move N variants to platform. Moved variants become top-level BBs on the destination. |
| **Move BB single-BB** | Footer button on BB Details. Local-only, every mode. |
| **🩹 Force purge** | Legacy-status modal's per-row × Delete is now × Force purge — walks every nested array + ownership map and removes the entity from each. Bulk Delete-all uses the same purge. 🩺 Diagnose per-row alerts every model location for stuck entities. |
| **🏷 Status manager chip** | Permanent dashed-pill chip in the header stats row. Switcher dropdown inside the modal when multiple legacy statuses exist. Always reachable for inspection / repair. |
| **Always-show Sync + Import buttons** | Every platform shows both, with disabled placeholder when no fetch history, and 🔗 Set GitHub URL (admin, orange) when no platform URL — inline modal pastes URL + subdirectory and the active ⤓ Import button comes alive. |
| **Starter contributor seed** | Brand-new install / Reset seeds `MODEL.contributors` with the dashboard author. Same seed written to `dashboard-v1_0_0.json`. |

### What's new since rev. 5

| Area | Change |
|---|---|
| **Sync — pre-wipe** | Every sync now wipes every folder of each `(BB, section)` pair before replaying URLs. Files deleted on the remote drop out locally. Multiple URLs for the same section UNION correctly. |
| **Sync — live file count** | After every sync the platform / dashboard buttons show `↻ Sync · X files · Y removed` (Y in red). The per-BB button is simplified to `↻ Sync (N)` where N = working links only. |
| **Sync — dead-URL pruning** | If any URL returned 0 files, a 🗑 *Remove N dead URLs from history* button appears in the modal footer to drop them from `fetchHistory` in one click. |
| **Moveable + minimizable modals** | Every modal has a drag handle (⠿ + the whole header) and a ─ minimize button. Minimized = 360 × 48 px pill at the bottom-right; click to restore. Dashboard behind stays fully interactive. |
| **🔀 Move BB to platform** | New BB Details footer button. Pick a destination Technology Platform; the BB and all its files (GDS / OASIS, S-matrix, tests, fab, scripts, documents, EDA links, variants, fetch history, last-sync stats, ownership, AI cache) travel with it. Visible tab switches to destination and BB panel re-opens on the moved BB. |
| **Sync log** | Per-job log lines now show `+N files from this URL` or `⚠ 0 files — this URL is empty / removed on the remote`. |

### What's new since rev. 4

| Area | Change |
|---|---|
| **AI Insight (NEW)** | 🧠 button in header opens main panel: status, per-platform shortcuts, executive summaries. Configurable endpoint (Anthropic / OpenAI / OpenRouter / Ollama / vLLM / LM Studio), model, key, monthly token cap, three egress modes (metrics-only / metrics+extracts / full), three prompt styles (brief / balanced / deep). |
| **Per-BB AI tab** | Every BB gets a new 🧠 AI tab — deterministic metric extraction (S21 / S31 peak, imbalance, 1-dB BW, S11 / S22, cohort σ), citation discipline (un-cited numbers get a wavy red underline), content-hash cache, provenance record. 📋 Copy, ⬇ Download .md, 🗑 Clear cached summary. |
| **Chat agent** | 💬 multi-turn chat with six read-only tools (`dashboard_overview`, `list_platforms`, `list_bbs`, `get_bb_details`, `search_dashboard`, `get_contributor_stats`, `summarise_bb`). Anthropic native tool-use + OpenAI tools schema, history persisted, transcript export. |
| **Diagnostics** | 🔌 Test connection in Settings — fires minimal call, reports HTTP code + tokens + family with targeted hints for 401 / 403 / 404 / 429 / 5xx / CORS. 👁 Reveal API key, 📋 Copy, live key meta (length, family prefix, whitespace + mismatch warnings). |
| **Cost meter** | Per-month input + output token counts in header + Settings; monthly cap disables 🧠 buttons when reached. |
| **Contributor Excel export** | 📥 Download Excel report button in the Contributors modal (always visible, all modes). Five sheets: Summary, Per-platform pivot, BBs, Files, About. |
| **Modern AI logo** | Conic-gradient circle (purple → pink → orange → cyan), rotating ring, soft glow pulse. Three sizes. Replaces 🧠 emoji on the header button + per-BB AI tab. |

### What's new since rev. 3

| Area | Change |
|---|---|
| **Admin safety** | Three-layer block on admin publishes into `users/` (commit hard-block, strict externalize trigger, prune scope refusal) |
| **Cross-check analysis** | 🔎 New tool next to 🔀 resolver — load another dashboard JSON, get Common / Here-only / There-only splits, three donut charts (per-platform, here/there/common, variants), multi-sheet Excel report, selective per-BB zip download |
| **Variants** | First-class category: walker flags every sub-block / variant; donut + Excel sheet; header chip `🌿 N variants` / `M total` |
| **Editable footer** | Admin can edit Terms / TAPR / Software footer texts inline; persisted to `localStorage`; reset-to-default per field |
| **Clear cache** | Visible in admin, user-admin, and read-only modes (duplicate removed) |
| **Prepare-for-PDK** | Available in Admin mode (was user-admin only) |
| **Scroll** | Fixed across every BB tab — inner ~3-item folder scroll with wheel fall-through, all × icons reachable |
| **Externalize** | Per-user subfolders named after tabs (`layout`, `smatrix`, `tests`, `fab`, `eda`, `scripts`, `documents`, `files`, `variants`) instead of `PDKMonitor_*`; EDA links externalize to `eda/eda_links.json` |
| **BB-card refresh** | Debounced `scheduleBoardRefresh()` in `saveModel` so badges update immediately after upload |
| **Layout / re-size** | `.title-area` `flex: 1 0 auto` (buttons wrap first, title stays); group-head wraps; BB-row reserves min-width for first 5 letters |
| **JSON loader** | Tolerant of every reasonable nesting (slice, snapshot, flat `entities[]`, etc.) |
| **Permissions** | User-admin can edit BBs created by other users (collective contributor model); destructive ops still owner-only |

### What's new since rev. 2

| Area | Change |
|---|---|
| **Layout formats** | GDS + OASIS (.oas / .oasis) accepted as essential layout files; SVG kept as preview-only fallback. OAS files store verbatim, round-trip losslessly through publish + Download; KLayout for the polygon view |
| **Prepare-for-PDK** | Per-section file multi-select, 📤 PR + ⚡ Direct dual buttons with cooldowns, no README on commit, no SVG upload, target-folder probe before direct commit. OAS uploads labelled "(OASIS layout)" in the picker |
| **Cooldowns** | Direct commit: progressive (2/min → 5/10 min → slows). PR: 1/hour. Per identity, persisted, admin bypasses |
| **Commit tests to repo** | Editable target URL, saved per-BB |
| **Scripts fetch** | Accepts any file — textual files as editable source, binaries as `binaryContent` |
| **S-matrix fetch** | Touchstone variants, HDF5, MAT/NPZ, TDMS, plus extension-less files all accepted |
| **Cross-user downloads** | Lazy-hydrate from any enabled Distribution source on ⬇ click. First click hits GitHub, then cached. Correct MIME on save. |
| **Manage-lists BB types** | `bbTypeLabel()` resolves custom-added types everywhere (Details, YAML, PR body, search, exports) — no more raw `x_9pogrls` id |
| **Scroll** | Single panel scrollbar + inner ~3-item folder scroll with proper wheel fall-through. × on every row reachable. |
| **User-admin permissions** | Can now edit BBs created by other users (collective contributor model) |

## At a glance

A self-contained HTML dashboard for silicon-photonics PDK content
that you can open in any modern browser. No install, no server,
no build step. Tracks Building Blocks across multiple technology
platforms, stores GDS / S-matrix / test / fab files, runs Python
scripts against the data in-browser, and synchronises with a team
through GitHub.

## What's in the box

| File | What it is |
|---|---|
| `pdk-monitor.html` | The dashboard. Open in any modern browser. |
| `pdk-monitor-v1_0_0.html` | Versioned copy for direct upload to a GitHub release page. |
| `dashboard-v1_0_0.json` | Canonical starter dashboard — host alongside the HTML for fresh installs. |
| `PDK-Monitor-User-Manual.pdf` | Full user manual (PDF, printable). |
| `PDK-Monitor-User-Manual.docx` | Same manual as a Word document. |
| `TERMS.md` | Terms of use. |
| `LICENSE-TAPR.txt` | TAPR Open Hardware License v1.0. |
| `CHANGELOG.md` | Per-version change log. |
| `RELEASE_NOTES.md` | This file. |
| `README.md` | One-page overview + quick start. |

## Three roles, clean separation

| Role | Can | Cannot |
|---|---|---|
| **Read-only** | View, search, run scripts, download | Edit anything |
| **User-admin** | All Read-only + own their `users/<id>/` folder fully | Touch the main `dashboard.json` |
| **Admin** | Everything | n/a |

## Real-files architecture

Every uploaded binary item (CSV, GDS, S-matrix touchstone, document,
script) is written to the repo as a SEPARATE FILE under
`users/<id>/<section>/<bb-name>__<id-suffix>/<filename>`. The
`dashboard.json` itself stays small (metadata + `repoPath` only)
and pool members hydrate the real bytes on fetch.

### Add / remove / nuke

* **Add** — upload locally + ⚡ Direct commit → file appears in
  the repo.
* **Remove** — delete locally + ⚡ Direct commit → file is pruned
  from the repo on the same publish.
* **Nuke** — 🗑 Wipe my repo folder → every file under `users/<id>/`
  is deleted; local model untouched; next publish rebuilds.

The repo folder is a true write-back mirror of the user-admin's
local state.

## Multi-user pool — one click

Open *Distribution → Fetch & adopt* → click **📚 Fetch user repos**
in the *Multi-user pool sync (advanced)* drawer. The dashboard:

1. Walks every enabled source.
2. Tries every plausible `users/` location (sibling, parent +
   `/users`, repo-root `/users`, `OpenSource_PDKMonitor/users`).
3. For each `users/<id>/dashboard.json`, fetches the metadata AND
   downloads every real file the slice references.
4. Stages the lot for merge.

Click **Merge into my dashboard** and you have a complete
multi-user view of every contributor's work with their actual lab
data (S-matrix, test results, datasheets, scripts) integrated into
your local copy.

## Duplicate resolver — bulk select + bulk actions

After fetching from multiple sources, name collisions are common
(same MMI 1x2 in three platforms; same Photodetector defined by
two contributors). The resolver makes cleanup a one-click job.

**Toolbar:**

```
Found 7 clusters: 2 BB · 0 platform · 0 tab · 5 cross-platform
☐ Select all   0 selected   [📥 Merge N selected]  [🌿 Variants N selected]  [🚀 Auto-resolve all (7)]
```

* **Per-cluster checkboxes** — tick the clusters you want to act
  on (same-parent or cross-platform; mix freely).
* **Select all / Deselect all** master checkbox.
* **📥 Merge N selected** — applies the standard merge to every
  ticked cluster. Cross-platform clusters honour any keeper you
  selected via the per-cluster radio buttons.
* **🌿 Variants N selected** — attaches the other copies as
  variants of the keeper for every ticked cross-platform cluster
  (same-parent clusters fall back to a regular merge).
* **🚀 Auto-resolve all** — auto-picks keepers by content score
  (most files / scripts / tests + most recent), merges every
  cluster including cross-platform. Confirm prompt itemises
  what's about to change.
* Selection state survives re-scans (keyed by cluster signature),
  so partial merges don't reset your remaining picks.

A local Backup `.json` downloads before any change.

## Quick start

1. Download `pdk-monitor-v1.0.0.zip` from the release.
2. Open `pdk-monitor.html` in your browser.
3. Sign in: click the mode pill in the header, type the default
   admin password `CS2026_PDK_Design&Test` (change it from
   *Manage → Passwords* afterwards).
4. Pull a real PDK from GitHub:
   * Click *Edit* on a Technology Platform column.
   * Paste the platform's GitHub folder URL.
   * Save → click **⤓ Import platform**.
5. Configure a Shared repository in the Distribution panel,
   ⚡ Direct commit your work, and invite team members to
   fetch it.

## Limits

* Per-file upload: up to **50 MB** (GitHub contents API limit).
* Total project size: ~10 GB across all files in browser IndexedDB.
* Recommended pool size: up to ~20 user-admin slices per main repo.

## Compatibility

* Chrome / Edge / Firefox / Safari (latest stable + one).
* GitHub PAT with `repo` scope is recommended for private repos
  and to lift the 60 req/h public rate limit.

## Author

**Emre Kaplan** — a.emrekaplan@gmail.com

The portal is open to everyone for further development.
