# Changelog — CORNERSTONE Open Platform PDK Monitor

All notable changes to this project will be documented in this file. The
format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to [Semantic Versioning](https://semver.org/).

## [1.0.0] — 2026-05-27 *(rev. 3 — Prepare-for-PDK, cooldowns, fetch fidelity)*

Same v1.0.0 stamp. Rev. 3 lands a polished cross-user contribution
flow (Prepare for community PDK with per-section file multi-select,
two-button publish with sensible cooldowns), accepts every file type
in Scripts / S-matrix GitHub fetch, and finally makes downloading
another contributor's file return the original bytes instead of a
JSON sidecar.

### Added (rev. 3)

- **Prepare-for-PDK — per-section file multi-select.** Every row in
  the Prepare-for-PDK modal's section-target table now shows a
  `📄 N/M ▾` toggle. Expand to see every file that section would
  commit, each with its own checkbox. Select-all / Clear buttons
  per panel. Selection persists per-BB in `localStorage`. Untick
  individual files to exclude them — useful for landing only the
  GDS + YAML and leaving WIP datasets behind, or skipping a single
  noisy test file from a folder.
- **Dual publish buttons with separate cooldowns.** The Prepare
  modal now exposes two publish paths side-by-side:
  - **📤 Open Pull Request** — groups all files by target repo and
    opens one PR per `(owner, repo, branch)`. Throttled to **1 PR
    per hour per identity** to keep reviewers' notifications sane.
    Failed PRs don't burn the slot.
  - **⚡ Direct commit** — commits straight to each target branch.
    Lenient progressive backoff: 0 s, 30 s, 90 s, 180 s, 300 s,
    600 s, 1200 s. Allows **2 commits inside 1 min** and
    **5 commits inside 10 min**, then gradually slows. Per-identity
    in `localStorage`. Admin role bypasses both.
- **Live cooldown countdown.** Both buttons show a 1-Hz ticker
  ("📤 PR available in 47m 03s", "⚡ Direct commit (2m 14s)") so
  the user always knows when the next attempt is available.
- **Editable target URL in Commit-tests-to-repo.** The previous
  static URL line is now an editable input pre-filled with the
  computed `<platform>/test/<bb>/` path. Saved per-BB in
  `localStorage["pdk-monitor.commitTestsTarget"]`. A **Reset to
  default** button repopulates the field. On commit, the edited
  URL is parsed by `parseGithubUrl` and used as the destination —
  so tests can be committed anywhere (e.g. your own
  `users/<id>/<bb>/tests/`).
- **Scripts GitHub fetch — accepts any file type.** Previously
  only `.py` files landed in the Scripts tab; everything else
  silently leaked into Tests. Now Scripts fetch routes textual
  files (`.py`, `.ipynb`, `.sh`, `.js`, `.ts`, `.m`, `.r`,
  `.jl`, `.f90`, `.c/.h/.cpp`, `.java`, `.go`, `.rs`, `.sql`,
  `.md`, config formats, etc.) as editable source, and binaries
  (`.exe`, `.so`, `.jar`, …) as base64 `binaryContent` so they
  survive publish round-trips.
- **S-matrix GitHub fetch — broader extension set.** Touchstone
  variants `.s/y/z/h/gNp`, `.hdf5`/`.h5`, `.tdms`, `.mat`,
  `.npz`/`.npy`, `.prn`, `.asc`, `.out`, `.log`, `.pickle`/`.pkl`,
  `.cti`/`.cit`, plus the previous CSV/TSV/XLSX/JSON/TXT list are
  all accepted. Small extension-less files are also kept so labs
  that emit untyped touchstone dumps work.
- **Lazy-hydrate on Download for cross-user items.** When a file
  card carries a `repoPath` but no in-memory bytes (the typical
  state for files contributed by another user-admin after the
  publish-strip), clicking ⬇ Download now walks every enabled
  Distribution source, fetches the bytes via the GitHub Contents
  API (with `git/blobs` fallback for files > 1 MB), writes them
  back onto the record, and completes the download with the
  original filename and bytes. First click hits GitHub, every
  subsequent click is local. So `S21_meas.csv` from another user
  now comes down as a real CSV instead of a `.metadata.json`
  sidecar.
- **Correct MIME on download.** The saved Blob is now tagged
  with the right Content-Type for the filename (text/csv,
  application/pdf, image/png, application/x-yaml, etc.) instead
  of generic `application/octet-stream`. OS / browser show the
  right icon, open with the right app.
- **`bbTypeLabel(t)` resolver.** Custom BB types added via
  Manage-lists get a `uid("x")` id (e.g. `x_9pogrls`). The id was
  surfacing raw on the BB Details "Type" field, the YAML export,
  the PR body, the markdown portfolio report, and the Excel
  export. A new label resolver (same shape as `statusLabel` /
  `categoryLabel`) looks up the matching `MODEL.bbTypes` entry by
  id or name. Plumbed through every user-facing render site.
  Search index now matches against both the raw id and the
  resolved label, so typing "heater" finds BBs whose `bbType` is
  `x_9pogrls` but whose Manage-list label is "heater".

### Removed (rev. 3)

- **No README on Prepare-for-PDK publish.** The auto-generated
  `<bb>.README.md` upload has been removed from both the commit
  flow and the BB zip download — only principal files (GDS /
  YAML / datasets / scripts / docs / `eda_links.json` / variants)
  land in the target. The PR body still carries a description
  when publishing as a PR.
- **No SVG upload on Prepare-for-PDK.** SVG previews are
  procedural and regenerable from the GDS or BB type at render
  time; they no longer ship to the community PDK to keep the
  target folder clean.

### Fixed (rev. 3)

- **File-list scroll inside Tests / S-matrix / Fab tabs.** The
  unreachable-× bug and the "scroll doesn't work at all"
  regression had a single root cause: three nested scroll
  containers (`.panel-body`, `.folder-list-wrap`,
  `.folder-body`) fighting over the same wheel events. Fix:
  - `.panel-body` and `.modal-body` get `min-height: 0` so the
    flex layout can actually shrink them to their allocated
    space and `overflow-y: auto` engages a real scrollbar.
  - `.folder-list-wrap` drops its `max-height: 72vh` cap — the
    outer panel scroll covers it.
  - `.folder-body` keeps an inner scroll at `max-height: 280px`
    (~3 file cards) so opening a 30-file folder still shows a
    compact card, with `overscroll-behavior: contain` to let
    wheel events fall through to the outer scroll once the
    inner reaches a boundary. Extra `padding-bottom` +
    `scroll-padding-bottom` so the last row's wrapped action
    buttons (including ×) are always reachable.
- **Prepare-for-PDK GDS missing on fetch.** Root cause: the
  modal was mutating `e.gdsRepoPath` to point at the
  cornerstone-community target after upload, but adopters
  hydrate from the SOURCE repo (the user's slice), not the
  target. Fix: never mutate `gdsRepoPath` / `repoPath` in
  Prepare-for-PDK; those track the user's own slice. Added
  re-fetch from the user's source repo when bytes are stripped
  after externalize.
- **Prepare-for-PDK YAML routing.** Layout section dropdown now
  spells out that the GDS / OASIS + YAML descriptor both land
  in `components/<bb>/`. Fabrication dropdown renamed from
  "Fabrication artefacts" to "🔬 Fabrication". Added a
  **Create new folders if missing** tick (default ON) so an
  off-by-one typo can no longer create stray directories.
- **User-admin BB edit rights.** User-admins can now edit all
  BBs created by other users (collective contributor model).
  Previously they could only edit their own. `canModifyId(id)`
  simplified to: admin → true, user-admin → true regardless of
  owner, read-only → false.

---

## [1.0.0] — 2026-05-26 *(rev. 2)*

Final post-release polish bundled into the v1.0.0 stamp. Same public
version number — every patch below is an incremental fix or feature
that landed during the first 48 hours of feedback.

### Added — post-release patches (rev. 2)

- **Selective fetch picker** — 📚 Fetch user repos now opens a
  checklist of every discovered slice before pulling; user ticks
  which ones to install. Default: all ticked.
- **Read-only column + side-panel resize** — both resize handles
  visible in read-only (layout-only state, persisted locally; side
  panel width to `localStorage`).
- **🧹 Clear cache button for read-only** — the Reset button is
  now visible in read-only mode with a "Clear cache" label.
  Wipes IndexedDB + localStorage + sessionStorage and reseeds
  factory defaults. Nothing on GitHub is touched.
- **Per-row Skip / Merge-in checkboxes in cross-platform
  resolver** — lets the user choose which non-keeper copies
  actually fold into the keeper, instead of all-or-nothing.
- **Backfill ownership from `who` at model load** — `ensureLists`
  now fills `MODEL.ownership[id]` from each item's `who` field
  when the map entry is missing. Fixes "user-admin can't delete
  their own legacy uploads".
- **Opt-out for auto-walk of `users/`** — checkbox in Fetch &
  adopt, **default OFF**. 📥 Fetch all enabled sources now pulls
  ONLY the configured main `dashboard.json` (no silent fold-in of
  every user contribution). Tick to restore prior auto-walk.
- **📦 Download .zip button per BB** — packs every file on a BB
  (GDS, S-matrix, tests, fab, scripts, documents, files) into a
  single zip with the CORNERSTONE folder layout
  (`components/sparams/characterisation/fabrication/scripts/documents/`)
  plus an auto-generated YAML descriptor.
- **Auto-generated YAML on GDS upload** — when a `.gds` is
  uploaded for a BB, the dashboard auto-parses the layers used
  and attaches a YAML descriptor (`<bb-slug>.yaml`) to the BB's
  Documents tab. Format mirrors the cornerstone-community
  `Si_220nm_passive` convention.
- **Photodetector sketch — material-neutral.** The procedural PD
  sketch no longer hard-codes Ge; the absorber gradient is now
  driven by the platform's `matStyle`. Title is just
  "Photodetector"; the absorber material is platform-determined.

### Fixed (rev. 2)

- Cross-platform resolver keeper choice now actually persists
  across re-renders (key mismatch between `data-sig` and the bare
  cross-platform sigKey).
- Auto-resolve all includes cross-platform clusters too — fixes
  the "always 0" report when only cross-platform dupes existed.
- On-load consolidator collapses pre-existing duplicate "Files" /
  "Imported" folders on every BB (cleans up dashboards that
  accumulated dupes from older versions).
- S-matrix fetch hydrate now re-parses bytes so CSVs render as
  📊 `N pts · Y traces` instead of inert raw text. Section-fetch
  walker now goes 5 levels deep; smatrix mode filters non-data
  extensions.

---

## [1.0.0] — 2026-05-26 *(initial public release)*

The official first public release of the CORNERSTONE Open Platform
PDK Monitor. Authored by **Emre Kaplan** during a focused 25-day
beta from 1 May 2026 → 26 May 2026.

### Architecture

- **Single-file HTML dashboard.** Open `pdk-monitor.html` in any
  modern browser — no install, no server, no build step. All state
  lives in the browser's IndexedDB + `localStorage`; sharing happens
  through GitHub.

- **Real-files architecture.** When a user-admin publishes their
  slice, every uploaded item (CSV, GDS, S-matrix file, document,
  script) is written as a SEPARATE real file in the repo under
  `users/<id>/<section>/<bb>/<filename>`. The `dashboard.json`
  carries only metadata + `repoPath` references. Pool members
  hydrate the real bytes on fetch.

- **Three-tier role model.**
  - **Admin** — full control, owns the main `dashboard.json`.
  - **User-admin** — owns their own `users/<id>/` folder; can
    publish, prune, and wipe it without ever touching the main
    `dashboard.json`.
  - **Read-only** — view, search, run scripts, download.

### Features

#### Platforms & BBs

- Multi-platform tabs (SOI 220, TFLN 300, SiN 200/300, etc.) with
  per-platform BB libraries grouped by BB type.
- Per-BB tabs: Overview, Layout (GDS), S-matrix, Tests, Fab,
  Scripts, Documents.
- Inline GDS preview rendered from raw GDS bytes; layer/datatype
  metadata exposed in the Layout tab.
- Custom sketch upload (PNG / SVG / JPG) per BB, with augmented
  procedural sketches as the default (material gradients, I/O
  arrows, dimension lines).
- Per-platform BB-type shortlist on the column head — filter
  visible BBs by type.

#### S-matrix / Tests / Fabrication

- Parsers for CSV / TSV / XLSX / S1P–S8P touchstone / DAT / JSON /
  TXT — every file type plots as `📊 N pts · Y traces`.
- Canonical "Files" folder per BB with the stable id
  (`sg_files` / `tg_files` / `ft_files`); on-load + post-merge
  consolidator collapses duplicate folders across version
  histories.
- Folder-name routing — a GitHub folder named `tests/` /
  `sparams/` / `fab/` auto-routes contents to the matching BB
  section.
- Per-section GitHub fetch with smart filtering (smatrix mode
  skips READMEs, licences, configs; depth-5 walker for nested
  layouts).

#### GDS Layers

- Top-level Layers list: name, layer/datatype, description, colour.
- Hover popover with full description.
- Sortable by layer number; filterable by BB type via the
  Manage-list dropdown.

#### Distribution & multi-user pool

- **Shared repositories** — configure multiple sources, each with
  enable / disable.
- **📥 Fetch all enabled sources** — pulls main `dashboard.json` +
  auto-walks every plausible `users/` location (sibling, parent,
  repo-root, `OpenSource_PDKMonitor/users`).
- **🔍 Discover user slices** — explicit walker, multi-pick UI.
- **🪪 Fetch my slice** *(user-admin)* — pulls + bootstraps the
  signed-in user's own slice.
- **📚 Fetch user repos** *(advanced)* — one-click pool assembly,
  walks every `users/<id>/` across every enabled source.
- **Merge into my dashboard** — additive, never overwrites local
  changes.
- **🔁 Replace whole dashboard** *(danger)* — wipes local copy +
  uses merged remote. Always downloads a Backup `.json` first.
- **📤 Publish as Pull Request** / **⚡ Direct commit** — both
  routes available; user-admin direct commits auto-route to their
  `users/<id>/dashboard.json` and externalize binaries to real
  files in their folder.
- **🌱 Seed user folders from sign-in list** *(admin)* — creates
  `users/<id>/dashboard.json` for every entry in the password list.
- **🗑 Wipe my repo folder** *(user-admin, danger)* — nuclear
  delete of every file under `users/<id>/`; local model untouched.

#### User-admin write-back mirror

- Every ⚡ Direct commit externalizes new / changed binary items as
  real files, then prunes orphan files that are no longer
  referenced — so the repo folder mirrors the local model
  exactly.
- Idempotent — re-publishing only uploads new / changed items.

#### Robustness

- Three-tier publish fallback: PUT → retry on conflict → git tree
  API. Survives BadObjectState / 422 / 500.
- Eight retries with exponential + jittered backoff.
- Heavy-binary strip (256 KB documents, 4 MB datasets, 2 MB parsed
  arrays) keeps `dashboard.json` under the GitHub contents API
  cap when binaries can't be externalized.
- Multi-location user folder discovery (sibling, parent + /users,
  repo-root, `OpenSource_PDKMonitor/users`).
- Hydrate re-parses CSV / XLSX / touchstone on fetch so adopters
  see real parsed data, not inert raw text.

#### Duplicate resolver

- Same-name BBs / groups / tabs collapsed via cluster picker.
- Cross-platform BB clusters with user-selectable keeper (radio
  buttons) and per-cluster "Merge into selected keeper" /
  "Attach as variants of keeper" actions.
- **Bulk select + bulk actions** — every cluster (same-parent and
  cross-platform) shows a checkbox. Tick the clusters you want
  to action, then use the toolbar buttons:
  - **Select all / Deselect all** master checkbox
  - **📥 Merge N selected** — applies the merge to every ticked
    cluster (cross-platform respects per-cluster radio choices)
  - **🌿 Variants N selected** — attaches the others as variants
    of the keeper for every ticked cross-platform cluster;
    same-parent clusters fall back to a regular merge
  - **🚀 Auto-resolve all (N)** — auto-picks keepers (most
    content + most recent) and merges every cluster, including
    cross-platform. Confirm prompt shows the cross-platform
    count separately. Selection state is preserved across
    re-scans by cluster signature.
- On-load consolidator runs automatically — folders with the same
  normalised name fold into one canonical folder per BB.

#### Scripts

- Inline Python runner (Pyodide-based) with sandbox.
- `data` / `tests` / `bb` globals expose parsed data.
- **💻 Run locally…** packs script + every BB file into a folder
  with VS Code / PyCharm / Sublime deeplinks.

#### Security

- Admin password lives in `localStorage` only — never published.
- User-admin sign-ins (guestPasswords) publish as
  `_distributedSecurity` so adopters get the sign-in list.
- GitHub token lives in `localStorage`; the dashboard never bundles
  it.

### Limits

- Per-file upload cap: 50 MB (smaller of GitHub contents API limit
  and browser memory).
- Total project size: ~10 GB across all files for the in-browser
  IndexedDB store.
- Recommended pool size: up to ~20 user-admin slices per main
  repository; pool assembly scales O(N) in API calls.

### What's in the bundle

```
pdk-monitor.html
pdk-monitor-v1_0_0.html        ← versioned copy for GitHub direct upload
dashboard-v1_0_0.json          ← canonical starter dashboard JSON
PDK-Monitor-User-Manual.pdf
PDK-Monitor-User-Manual.docx
TERMS.md
LICENSE-TAPR.txt
CHANGELOG.md
RELEASE_NOTES.md
README.md
```

### Licence

Hardware content: **TAPR Open Hardware License v1.0** (see
`LICENSE-TAPR.txt`).

### Credits

Authored by **Emre Kaplan** (a.emrekaplan@gmail.com) for the
CORNERSTONE Open Platform — the UK silicon-photonics rapid
prototyping foundry programme at the University of Southampton
(https://www.cornerstone.sotonfab.co.uk/).

The portal is open to everyone for further development.

---

## Development history (pre-1.0.0)

Daily-iteration log between the 1 May 2026 beta and the 26 May 2026
official release. Internal version numbers were used during this
period and are NOT part of the public versioning scheme — every
feature listed below is included in v1.0.0.

- Beta `b0.1` (01 May 2026) — initial single-page dashboard with
  platform list, BB list, basic file uploads.
- Platform import workflow + GDS parsing.
- GDS Layers list with hover popovers.
- Role-based access (admin / user-admin / read-only).
- Distribution panel (configure sources, fetch, merge, replace).
- Robust publish helper with PUT → retry → tree-API fallback.
- User-admin slice publishing into `users/<id>/dashboard.json`.
- Duplicate resolver (within-platform).
- Cross-platform duplicate resolver with variant attachment.
- Real-files architecture — externalize binaries, hydrate on fetch.
- Orphan file pruning on publish + 🗑 Wipe my repo folder button.
- Multi-location `users/` discovery (both single-file + directory
  modes).
- 📚 Fetch user repos one-click pool assembly.
- Empty S-matrix entries fix (hydrate re-parse + smatrix-only
  extension filter + depth-5 walker).
- On-load + post-merge duplicate folder consolidator.
